"""
IDE-only stub. vedbus (velib_python) is Victron's own library, bundled
inside Venus OS firmware -- there is no PyPI package and nothing to
install here. This file exists only so IntelliJ/PyCharm stop flagging
`from vedbus import VeDbusService` while editing on Windows. It is never
imported at runtime: outequipac.py's sys.path insertion at import time
points at the real Venus OS copy, which is only present on the Pi and
shadows this stub there. Do not add real logic here.
"""

from typing import Any, Callable, Optional


class VeDbusService:
    def __init__(self, servicename: str, bus: Any = ..., register: bool = ...) -> None: ...
    def add_path(
        self,
        path: str,
        value: Any,
        description: str = ...,
        writeable: bool = ...,
        onchangecallback: Optional[Callable[[str, Any], bool]] = ...,
        gettextcallback: Optional[Callable[[str, Any], str]] = ...,
    ) -> None: ...
    def register(self) -> None: ...
    def __getitem__(self, path: str) -> Any: ...
    def __setitem__(self, path: str, value: Any) -> None: ...
    def __enter__(self) -> "VeDbusService": ...
    def __exit__(self, *exc: Any) -> None: ...
