# VeOutEquipAC

Venus OS driver bridging an OutEquipPro rooftop AC's built-in BLE module
onto D-Bus, packaged for [kwindrem/SetupHelper](https://github.com/kwindrem/SetupHelper)'s
PackageManager.

**Read `NOTES.md` before installing.** The BLE characteristic UUIDs and
register map are inferred from Velit-branded units on the same platform,
not yet confirmed by direct capture against an OutEquip-branded module.

## Install

Requires SetupHelper already installed (Settings -> PackageManager on the
GX device / Remote Console). Then, either:

- **Via PackageManager:** Package Manager -> Inactive packages -> new ->
  GitHub user `pradeepk188`, repo `VeOutEquipAC`, branch/tag `latest` ->
  Install. You'll be prompted for the AC's BLE MAC address during install.

- **From the command line**, same pattern as installing any other
  SetupHelper package:
  ```
  wget -qO - https://github.com/pradeepk188/VeOutEquipAC/archive/latest.tar.gz | tar -xzf - -C /data
  mv /data/VeOutEquipAC-latest /data/VeOutEquipAC
  /data/VeOutEquipAC/setup
  ```

The repo name, the installed package directory (`/data/VeOutEquipAC`), and
`services/OutEquipAc/run`'s `cd` target now all match, so no renaming step
is needed beyond GitHub's own `<repo>-<tag>` archive folder naming.

`gitHubInfo` in this repo is `pradeepk188:latest` -- push a `latest`
tag/branch once you've verified the BLE layer against your hardware, since
that's what PackageManager will actually pull.

## Uninstall

Package Manager -> Active packages -> OutEquipAc -> Uninstall. This stops
the service and removes `mac.conf`.

## Files

| Path | Purpose |
| --- | --- |
| `setup` | SetupHelper-compatible install/uninstall script |
| `version`, `gitHubInfo` | Package metadata PackageManager reads |
| `outequipac.py` | Main driver: BLE poll loop + VeDbusService publishing |
| `ac_protocol.py` | Frame codec + register map for the Kingtec/Velit/OutEquip protocol |
| `ble_client.py` | bluepy-based BLE transport |
| `services/OutEquipAc/` | Service directory SetupHelper installs to `/service/OutEquipAc` |
| `NOTES.md` | Protocol confidence, open questions, verification steps, packaging notes |
