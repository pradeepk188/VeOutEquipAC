/*
  esp32_ble_test.ino -- standalone BLE test against the OutEquipPro AC,
  run directly on an ESP32 (ESP-WROOM-32D), bypassing the PC's BLE stack
  entirely.

  Why: dev-tools/ble_scan_test.py (Windows/bleak) showed a real GATT layout
  match (FFE0/FFE1/FFE2) but inconsistent connection behavior -- sometimes a
  clean round trip, sometimes an instant disconnect, sometimes a write that
  gets ACKed with zero application-level reply. NOTES.md documents another
  user (bobbaboui/outequip-ha) hitting the same kind of flakiness talking to
  this module family from a PC's onboard Bluetooth adapter (a different host
  than Windows), and solving it by moving the BLE connection onto a dedicated
  ESP32. This sketch is the equivalent test on your hardware: does a plain
  ESP32 talking directly to the module behave more reliably than a PC does?

  This mirrors ac_protocol.py's frame codec and ble_scan_test.py's Active(66)
  handshake logic, reimplemented in C++ since there's no way to share the
  Python module with ESP32 firmware directly.

  Setup:
    1. Arduino IDE -> File -> Preferences -> Additional Boards Manager URLs:
       https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
    2. Tools -> Board -> Boards Manager -> install "esp32" (Espressif Systems)
    3. Tools -> Board -> ESP32 Arduino -> "ESP32 Dev Module" (matches WROOM-32D)
    4. Tools -> Port -> select your ESP32's serial port
    5. Update TARGET_MAC below if your unit's address differs
    6. Upload, then open Tools -> Serial Monitor at 115200 baud

  No extra libraries to install -- BLEDevice.h etc. ship with the esp32
  board package.
*/

#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEScan.h>
#include <BLEAdvertisedDevice.h>

// ---- Configuration ---------------------------------------------------

static const char* TARGET_MAC = "E6:87:25:EC:B3:84";  // KT2026050001550

static BLEUUID SERVICE_UUID((uint16_t)0xFFE0);
static BLEUUID NOTIFY_UUID((uint16_t)0xFFE1);
static BLEUUID WRITE_UUID((uint16_t)0xFFE2);

// Which register the main test queries after the handshake. Matches
// ac_protocol.py's REG_MODE. Change to try others (7=intake_temp,
// 8=outlet_temp, 18=voltage, etc).
static const uint8_t TEST_REGISTER = 2;  // Mode

static const uint8_t REG_ACTIVE = 66;
static const unsigned long RESPONSE_TIMEOUT_MS = 3000;

// ---- Frame codec (mirrors ac_protocol.py) -----------------------------
//
// 5A 5A | len | devtype(1) | reg | val | checksum | 0D 0A
// checksum = 8-bit additive sum of every byte from preamble through value.

static size_t makeFrame(uint8_t reg, uint8_t value, uint8_t* out) {
  out[0] = 0x5A;
  out[1] = 0x5A;
  out[2] = 0x04;  // length: dev(1)+reg(1)+val(1)+checksum(1) = 4
  out[3] = 0x01;  // device type: air conditioner
  out[4] = reg;
  out[5] = value;
  uint8_t checksum = 0;
  for (int i = 0; i < 6; i++) checksum += out[i];
  out[6] = checksum;
  out[7] = 0x0D;
  out[8] = 0x0A;
  return 9;
}

// Returns true and fills outReg/outVal if `data` (length `len`) is one
// complete, valid frame. Prints a reason and returns false otherwise --
// this test sketch doesn't need to handle partial/streaming buffers since
// BLE notifications arrive as whole packets on this transport.
static bool decodeFrame(uint8_t* data, size_t len, uint8_t* outReg, uint8_t* outVal) {
  if (len < 9) {
    Serial.println("     decode: too short");
    return false;
  }
  if (data[0] != 0x5A || data[1] != 0x5A) {
    Serial.println("     decode: bad preamble");
    return false;
  }
  uint8_t length = data[2];
  uint8_t valueLen = length - 3;  // dev+reg+checksum = 3 non-value bytes
  if (valueLen != 1) {
    Serial.println("     decode: unexpected value length (multi-byte register?)");
    return false;
  }
  uint8_t reg = data[4];
  uint8_t val = data[5];
  uint8_t checksumIndex = 6;
  uint8_t checksum = data[checksumIndex];
  if (data[checksumIndex + 1] != 0x0D || data[checksumIndex + 2] != 0x0A) {
    Serial.println("     decode: bad postamble");
    return false;
  }
  uint8_t computed = 0;
  for (int i = 0; i < checksumIndex; i++) computed += data[i];
  if (computed != checksum) {
    Serial.printf("     decode: checksum mismatch got=0x%02X computed=0x%02X\n", checksum, computed);
    return false;
  }
  *outReg = reg;
  *outVal = val;
  return true;
}

// ---- BLE state ---------------------------------------------------------

static BLERemoteCharacteristic* pNotifyChar = nullptr;
static BLERemoteCharacteristic* pWriteChar = nullptr;

static volatile bool handshakeDone = false;
static volatile uint8_t handshakeValue = 0;
static volatile bool queryDone = false;
static volatile uint8_t queryValue = 0;

static void notifyCallback(BLERemoteCharacteristic* /*pChar*/, uint8_t* pData, size_t length, bool /*isNotify*/) {
  Serial.printf("  <- notification, %u bytes: ", (unsigned)length);
  for (size_t i = 0; i < length; i++) Serial.printf("%02X", pData[i]);
  Serial.println();

  uint8_t reg, val;
  if (!decodeFrame(pData, length, &reg, &val)) return;
  Serial.printf("     decoded: register=%u value=%u\n", reg, val);

  if (reg == REG_ACTIVE && !handshakeDone) {
    handshakeValue = val;
    handshakeDone = true;
  } else if (reg == TEST_REGISTER) {
    queryValue = val;
    queryDone = true;
  }
}

class ClientCallbacks : public BLEClientCallbacks {
  void onConnect(BLEClient* /*pClient*/) override {
    Serial.println("BLE: onConnect");
  }
  void onDisconnect(BLEClient* /*pClient*/) override {
    Serial.println("BLE: onDisconnect");
  }
};

static bool sendFrame(uint8_t reg, uint8_t value) {
  uint8_t frame[9];
  size_t n = makeFrame(reg, value, frame);
  Serial.print("-> sending: ");
  for (size_t i = 0; i < n; i++) Serial.printf("%02X", frame[i]);
  Serial.println();
  if (pWriteChar == nullptr) return false;
  pWriteChar->writeValue(frame, n, false);  // false = write without response
  return true;
}

void setup() {
  Serial.begin(115200);
  delay(2000);
  Serial.println();
  Serial.println("=== ESP32 direct BLE test against OutEquipPro AC ===");
  Serial.printf("Target: %s\n", TARGET_MAC);

  BLEDevice::init("");
  BLEClient* pClient = BLEDevice::createClient();
  pClient->setClientCallbacks(new ClientCallbacks());

  Serial.println("Connecting...");
  bool ok = pClient->connect(BLEAddress(TARGET_MAC));
  if (!ok) {
    Serial.println("FAILED to connect. Check TARGET_MAC and that nothing else");
    Serial.println("(phone app) is currently connected -- BLE allows one central.");
    return;
  }
  Serial.println("Connected.");

  BLERemoteService* pService = pClient->getService(SERVICE_UUID);
  if (pService == nullptr) {
    Serial.println("FAILED: service FFE0 not found. Run the Python dump");
    Serial.println("tool again to double check the UUIDs on this unit.");
    return;
  }

  pNotifyChar = pService->getCharacteristic(NOTIFY_UUID);
  pWriteChar = pService->getCharacteristic(WRITE_UUID);
  if (pNotifyChar == nullptr || pWriteChar == nullptr) {
    Serial.println("FAILED: FFE1/FFE2 characteristic not found.");
    return;
  }

  if (pNotifyChar->canNotify()) {
    pNotifyChar->registerForNotify(notifyCallback);
    Serial.println("Subscribed to notifications on FFE1.");
  } else {
    Serial.println("FAILED: FFE1 does not support notify.");
    return;
  }

  // Handshake: query Active (66); if it replies 2, write 1 back. Mirrors
  // protocol.md's Initialization section and ble_scan_test.py's handshake.
  Serial.println("-> handshake: querying Active (66)");
  sendFrame(REG_ACTIVE, 0);
  unsigned long start = millis();
  while (!handshakeDone && millis() - start < RESPONSE_TIMEOUT_MS) {
    delay(20);
  }
  if (handshakeDone) {
    Serial.printf("   Active replied with value=%u\n", handshakeValue);
    if (handshakeValue == 2) {
      Serial.println("-> handshake: Active==2, writing Active=1 per protocol.md");
      sendFrame(REG_ACTIVE, 1);
      delay(500);
    }
  } else {
    Serial.println("   no reply to Active handshake within timeout -- proceeding anyway");
  }

  Serial.printf("-> sending query for register %u\n", TEST_REGISTER);
  sendFrame(TEST_REGISTER, 0);
  start = millis();
  while (!queryDone && millis() - start < RESPONSE_TIMEOUT_MS) {
    delay(20);
  }
  if (queryDone) {
    Serial.printf("SUCCESS: register %u = %u\n", TEST_REGISTER, queryValue);
    Serial.println("ac_protocol.py's codec and this GATT layout are confirmed");
    Serial.println("working end-to-end against real hardware, from the ESP32.");
  } else {
    Serial.printf("No response for register %u within %lums.\n", TEST_REGISTER, RESPONSE_TIMEOUT_MS);
  }
}

void loop() {
  // One-shot test; nothing to do here. Re-flash or reset the board to
  // run it again.
  delay(5000);
}
