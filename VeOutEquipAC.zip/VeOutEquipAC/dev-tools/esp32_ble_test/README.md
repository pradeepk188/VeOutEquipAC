# esp32_ble_test

Standalone Arduino sketch that tests BLE communication with the AC
**directly from an ESP32**, bypassing the PC's BLE stack entirely. See
`NOTES.md` in the repo root for why: `dev-tools/ble_scan_test.py` (Windows/
bleak) found the right GATT layout but inconsistent connection behavior,
and another user with this same module family (`bobbaboui/outequip-ha`)
documented similar flakiness on a PC's onboard Bluetooth and solved it by
moving the connection onto a dedicated ESP32. This sketch is the same test
on your hardware.

## Setup (Arduino IDE)

1. File -> Preferences -> Additional Boards Manager URLs, add:
   ```
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
   ```
2. Tools -> Board -> Boards Manager -> search "esp32" -> install the
   Espressif Systems package. No other libraries needed -- `BLEDevice.h`
   etc. ship with this package.
3. Tools -> Board -> ESP32 Arduino -> **ESP32 Dev Module** (matches a
   plain ESP-WROOM-32D).
4. Tools -> Port -> pick your board's serial port.
5. Open `esp32_ble_test.ino`, check `TARGET_MAC` matches your unit
   (currently `E6:87:25:EC:B3:84`), Upload.
6. Tools -> Serial Monitor, set baud to **115200**.

Power-cycle the AC and make sure the phone app is disconnected before
running (BLE allows one connection at a time -- same constraint as the
Python tool).

## What it does

One-shot on boot: connects, confirms the `FFE0` service and `FFE1`/`FFE2`
characteristics exist, subscribes to notifications, sends the `Active`
(66) handshake per `protocol.md`'s Initialization section, then queries
register 2 (Mode) and prints whatever comes back. Change `TEST_REGISTER`
near the top to try others (7=intake_temp, 8=outlet_temp, 18=voltage).

Reset the board (or re-upload) to run it again -- it's one-shot, not a
polling loop.

## Reading the result

- **A decoded `register=2 value=...` line appears** -- the ESP32 got a
  real reply. That's the strongest evidence yet that the protocol/codec
  logic is right and the PC-side BLE stack (not the AC, not the protocol)
  was the source of the earlier flakiness. Worth then testing a few more
  registers, and this becomes a strong argument for routing the real
  Venus OS driver's BLE traffic through an ESP32 relay rather than the
  Pi's onboard Bluetooth, if the Pi proves flaky too.
- **Still nothing, even from the ESP32** -- that would be surprising
  given the evidence gathered so far, and would point back toward the
  frame/protocol content itself rather than any particular host's BLE
  stack. At that point the HCI snoop capture (see `NOTES.md`) becomes the
  clear next step, since it's the only way left to see the exact bytes
  the real app sends.
